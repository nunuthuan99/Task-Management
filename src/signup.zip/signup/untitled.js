import React from "react";
import {Signup} from './signup.page'


export default function Signup() {
  return <Signup />
};

