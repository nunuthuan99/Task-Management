import React from "react";
import {SignupPage} from './signup.page'


export default function Signup() {
  return <SignupPage />
};

